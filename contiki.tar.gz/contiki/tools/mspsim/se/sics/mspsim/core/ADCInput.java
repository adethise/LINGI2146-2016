package se.sics.mspsim.core;

public interface ADCInput {
  public int nextData();
}
